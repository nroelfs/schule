<!DOCTYPE html>
<html lang="de">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="../css/Schreinerwerkstatt.css"/>
    <title>Kontakt</title>
  </head>
  <body>
	<header>
		<img src="../img/logo.svg" alt="logo">
		<h2>Kontakt</h2>
	</header>
	<main>
		<article>
            <h2>Wir werden uns schnellstmöglich mit Ihnen in Verbindung setzen</h2>
		</article>
		<article>

            <p>            
                <?php
                    $name = $_POST['name'];
                    $vName = $_POST['vName'];
                    echo "Name, Vorname: " . $name  . "/ " .  $vName;
                 ?>
            </p>
            <?php
                $eMail = $_POST['eMail'];
                echo "E-Mail-Adresse: " . $eMail;
            ?>
            <p></p>
            <?php
                $tel = $_POST['tel'];
                echo "Telefonnummer: " . $tel;
            ?>
		</article>
        <article>
        <article>
			<a href="../index.php">Zurueck zur Startseite</a>
		</article>
        </article>
	</main>

	<footer>
		<p></p>
	</footer>
	
	<div>
		
	</div>
	
  </body>
</html>